import Meta from 'gi://Meta';
import Shell from 'gi://Shell';
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import Soup from 'gi://Soup?version=3.0';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import {Extension} from 'resource:///org/gnome/shell/extensions/extension.js';

import {LauncherOverlay} from './ui/launcherOverlay.js';
import {AppsProvider} from './lib/providers/apps.js';
import {WindowsProvider} from './lib/providers/windows.js';
import {RecentsProvider} from './lib/providers/recents.js';
import {CalculatorProvider} from './lib/providers/calculator.js';
import {CurrencyProvider} from './lib/providers/currency.js';
import {TimezoneProvider} from './lib/providers/timezone.js';
import {EmojiProvider} from './lib/providers/emoji.js';
import {FilesProvider} from './lib/providers/files.js';
import {WeatherProvider} from './lib/providers/weather.js';
import {WebSearchProvider} from './lib/providers/webSearch.js';
import {makeSettingsGatedProvider} from './lib/providerToggleWrapper.js';
import {buildProviderFeatureMap} from './lib/providerFeatureMap.js';

const KEY_TOGGLE = 'toggle-launcher';

Gio._promisify(Soup.Session.prototype, 'send_and_read_async', 'send_and_read_finish');

function createSoupRequestJson() {
    const session = new Soup.Session({
        user_agent: 'hop-launcher/1.0',
    });

    return async url => {
        const message = Soup.Message.new('GET', url);
        const bytes = await session.send_and_read_async(message, GLib.PRIORITY_DEFAULT, null);
        const status = Number(message.status_code ?? message.get_status?.());
        if (!Number.isFinite(status) || status < 200 || status >= 300)
            throw new Error(`weather http ${status}`);

        const payload = bytes.get_data();
        const json = typeof payload === 'string'
            ? payload
            : new TextDecoder().decode(payload);
        return JSON.parse(json);
    };
}

export default class HopLauncherExtension extends Extension {
    enable() {
        this._settings = this.getSettings('org.hoplauncher.app');
        const openUrl = url => {
            try {
                Gio.AppInfo.launch_default_for_uri(url, null);
            } catch (error) {
                logError(error, '[hop-launcher] open url failed');
            }
        };
        const providers = buildProviderFeatureMap({
            windows: new WindowsProvider(),
            apps: new AppsProvider(),
            recents: new RecentsProvider(),
            files: new FilesProvider(this._settings),
            emoji: new EmojiProvider(),
            calculator: new CalculatorProvider(),
            timezone: new TimezoneProvider(),
            currency: new CurrencyProvider(this._settings),
            weather: new WeatherProvider({
                soupRequestJson: createSoupRequestJson(),
            }),
            webSearch: new WebSearchProvider(this._settings, {openUrl}),
        });
        this._providers = providers.map(([provider, key]) =>
            makeSettingsGatedProvider(provider, this._settings, key)
        );

        this._overlay = new LauncherOverlay(this._settings, this._providers, this.path);
        Main.layoutManager.addChrome(this._overlay);
        this._positionOverlay();

        this._monitorsChangedId = Main.layoutManager.connect('monitors-changed', () => this._positionOverlay());

        Main.wm.addKeybinding(
            KEY_TOGGLE,
            this._settings,
            Meta.KeyBindingFlags.NONE,
            Shell.ActionMode.ALL,
            () => this._toggle()
        );

        this._applyOverlayVisuals();
        this._overlayVisualSettingIds = [
            this._settings.connect('changed::blur-enabled', () => this._applyOverlayVisuals()),
            this._settings.connect('changed::overlay-translucency', () => this._applyOverlayVisuals()),
        ];
    }

    disable() {
        if (this._overlayVisualSettingIds?.length) {
            for (const id of this._overlayVisualSettingIds)
                this._settings.disconnect(id);
            this._overlayVisualSettingIds = [];
        }

        if (this._monitorsChangedId) {
            Main.layoutManager.disconnect(this._monitorsChangedId);
            this._monitorsChangedId = null;
        }

        Main.wm.removeKeybinding(KEY_TOGGLE);

        if (this._overlay) {
            this._overlay.destroyOverlay();
            this._overlay = null;
        }

        for (const provider of this._providers) {
            try {
                provider.destroy?.();
            } catch (error) {
                logError(error, '[hop-launcher] provider destroy failed');
            }
        }

        this._providers = [];
        this._settings = null;
    }

    _toggle() {
        if (!this._overlay)
            return;

        if (this._overlay.visible)
            this._overlay.close();
        else {
            // Recompute geometry at open time to keep overlay centered across dynamic layout changes.
            this._positionOverlay();
            this._overlay.open();
        }
    }

    _positionOverlay() {
        if (!this._overlay)
            return;

        const monitorIndex = Main.layoutManager.primaryIndex ?? global.display.get_primary_monitor();
        const monitor = Main.layoutManager.monitors?.[monitorIndex] ?? Main.layoutManager.primaryMonitor;
        if (!monitor)
            return;

        const workArea = Main.layoutManager.getWorkAreaForMonitor(monitorIndex);
        const width = Math.min(700, Math.floor(workArea.width * 0.8));
        const maxResultsHeight = Math.floor(workArea.height * 0.55);
        const topOffset = Math.floor(workArea.height * 0.18);

        this._overlay.set_width(width);
        this._overlay.set_height(-1);
        this._overlay.setMaxResultsHeight(maxResultsHeight);
        this._overlay.set_position(
            workArea.x + Math.floor((workArea.width - width) / 2),
            workArea.y + topOffset
        );
    }

    _applyOverlayVisuals() {
        if (!this._overlay)
            return;

        const blurEnabled = this._settings.get_boolean('blur-enabled');
        if (blurEnabled)
            this._overlay.add_style_class_name('blurred');
        else
            this._overlay.remove_style_class_name('blurred');

        this._overlay.applyVisualSettings({
            blurEnabled,
            translucencyPercent: this._settings.get_int('overlay-translucency'),
        });
    }
}
